<?php
extract($_POST);
extract($_FILES);
require('conectar.php');


    //palavras e expressões proibidas
$str = 'porra';
$str = 'caralho';
$str = 'filho da puta'; 
$str = 'filha da puta';
$str = 'arombado';
$str = 'arrombada';
$str = 'bicha';
$str = 'boiola';
$str = 'buceta';
$str = 'boquete'; 
$str = 'bosta';
$str = 'bronha';
$str = 'bunda'; 
$str = 'burra';
$str = 'burro';
$str = 'bêbado';
$str = 'cacete';
$str = 'corno';
$str = 'corna';
$str = 'canalha';
$str = 'criolo';
$str = 'cu';
$str = 'cuzão';
$str = 'debiloide';
$str = 'deficiente';
$str = 'demônio';
$str = 'doida';
$str = 'doido';
$str = 'escroto';
$str = 'escrota';
$str = 'facista';
$str = 'foda';
$str = 'fode';
$str = 'fudida';
$str = 'fudendo';
$str = 'gay';
$str = 'grelo';
$str = 'homo-sexual';
$str = 'idiota'; 
$str = 'imbecil';
$str = 'ladrão';
$str = 'leprosa';
$str = 'leproso';
$str = 'louco';
$str = 'louca';
$str = 'macaca';
$str = 'macaco';
$str = 'macumbeiro';
$str = 'macumbeiro';
$str = 'mulata';
$str = 'mulato';
$str = 'nazista';
$str = 'otario';
$str = 'otaria';
$str = 'perereca';
$str = 'pinto';
$str = 'piranha';
$str = 'prostituo';
$str = 'prostituta';
$str = 'punheta';
$str = 'puta';
$str = 'puto';
$str = 'pênis';
$str = 'retardada';
$str = 'retardado';
$str = 'ridícula';
$str = 'racista';
$str = 'safado';
$str = 'safada';
$str = 'sapatão';
$str = 'sifilis';
$str = 'siririca'; 
$str = 'tarado';
$str = 'tarada';
$str = 'trouxa';
$str = 'traveco';
$str = 'vaca';
$str = 'vadia';
$str = 'viado';
$str = 'xereca';
$str = 'xota';
$str = 'vai toma no cu';
$str = 'lixo';


   
    if(strpos($nome, 'caralho') !== false || strpos($nome, 'porra') !== false || strpos($nome, 'filho da puta') !== false || strpos($nome, 'filha da puta') !== false || strpos($nome, 'arrombado') !== false || strpos($nome, 'arromada') !== false || strpos($nome, 'bicha') !== false || strpos($nome, 'boiola') !== false || strpos($nome, 'buceta') !== false || strpos($nome, 'boquete') !== false || strpos($nome, 'bosta') !== false || strpos($nome, 'bronha') !== false || strpos($nome, 'bunda') !== false || strpos($nome, 'burra') !== false || strpos($nome, 'burro') !== false || strpos($nome, 'bêbado') !== false || strpos($nome, 'cacete') !== false || strpos($nome, 'corno') !== false || strpos($nome, 'corna') !== false || strpos($nome, 'canalha') !== false || strpos($nome, 'criolo') !== false || strpos($nome, 'cu') !== false || strpos($nome, 'cuzão') !== false || strpos($nome, 'debiloide') !== false || strpos($nome, 'deficiente') !== false || strpos($nome, 'demônio') !== false || strpos($nome, 'doida') !== false || strpos($nome, 'doido') !== false || strpos($nome, 'escrota') !== false || strpos($nome, 'escroto') !== false || strpos($nome, 'facista') !== false || strpos($nome, 'foda') !== false || strpos($nome, 'fode') !== false || strpos($nome, 'fudida') !== false || strpos($nome, 'fudendo') !== false || strpos($nome, 'gay') !== false || strpos($nome, 'grelo') !== false || strpos($nome, 'homo-sexual') !== false || strpos($nome, 'idiota') !== false || strpos($nome, 'imbecil') !== false || strpos($nome, 'ladrão') !== false || strpos($nome, 'lebrosa') !== false || strpos($nome, 'lebroso') !== false || strpos($nome, 'louco') !== false || strpos($nome, 'louca') !== false || strpos($nome, 'macaca') !== false || strpos($nome, 'macaco') !== false || strpos($nome, 'macumbeiro') !== false || strpos($nome, 'macumbeira') !== false || strpos($nome, 'mulata') !== false || strpos($nome, 'mulato') !== false || strpos($nome, 'nazista') !== false || strpos($nome, 'otaria') !== false || strpos($nome, 'otario') !== false || strpos($nome, 'perereca') !== false || strpos($nome, 'pinto') !== false || strpos($nome, 'piranha') !== false || strpos($nome, 'prostituto') !== false || strpos($nome, 'prostituta') !== false || strpos($nome, 'punheta') !== false || strpos($nome, 'puto') !== false || strpos($nome, 'puta') !== false || strpos($nome, 'pênis') !== false || strpos($nome, 'retardada') !== false || strpos($nome, 'retardado') !== false || strpos($nome, 'ridícula') !== false || strpos($nome, 'racista') !== false || strpos($nome, 'safada') !== false || strpos($nome, 'safado') !== false || strpos($nome, 'sapatão') !== false || strpos($nome, 'sífilis') !== false || strpos($nome, 'siririca') !== false || strpos($nome, 'tarada') !== false || strpos($nome, 'tarado') !== false || strpos($nome, 'trouxa') !== false || strpos($nome, 'traveco') !== false || strpos($nome, 'vaca') !== false || strpos($nome, 'vadia') !== false || strpos($nome, 'viado') !== false || strpos($nome, 'xereca') !== false || strpos($nome, 'xota') !== false || strpos($nome, 'vai toma no cu') !== false || strpos($nome, 'lixo') !== false){
        header("location:contato.php"); 
        $msg ="<div class = alertaRedLinguagem>Cuidado com a linguagem!! Por favor, utilize palavras apropriadas para o contato conosco</div>";
    }else if($nome == "" || $problema == ""){
        header("location:contato.php");
        $msg= "<div class = alertaRedEmail>Preencha os campos de identificação</div>";
       

    }else{
        if(mysqli_query($tec, "INSERT INTO `tb_contato` 
        (`codContato`, `nome`, `problema`, `descriProblema`) 
            VALUES (NULL, '$nome', '$problema', '$descriProblema');")){
            $msg ="<script>alert('obrigado pela sua informação, entraremos em contato com você!!')</div>";
            header("location:feed.php");

                
        }

        }


@session_start();
 $_SESSION['msg'] = $msg;
//header("location:feed.php");

?>