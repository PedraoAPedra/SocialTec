<?php
extract($_POST);
require('conectar.php');
$str = 'porra';
$str = 'caralho';
$str = 'filho da puta'; 
$str = 'filha da puta';
$str = 'arombado';
$str = 'arrombada';
$str = 'bicha';
$str = 'boiola';
$str = 'buceta';
$str = 'boquete'; 
$str = 'bosta';
$str = 'bronha';
$str = 'bunda'; 
$str = 'burra';
$str = 'burro';
$str = 'bêbado';
$str = 'cacete';
$str = 'corno';
$str = 'corna';
$str = 'canalha';
$str = 'criolo';
$str = 'cu';
$str = 'cuzão';
$str = 'debiloide';
$str = 'deficiente';
$str = 'demônio';
$str = 'doida';
$str = 'doido';
$str = 'escroto';
$str = 'escrota';
$str = 'facista';
$str = 'foda';
$str = 'fode';
$str = 'fudida';
$str = 'fudendo';
$str = 'gay';
$str = 'grelo';
$str = 'homo-sexual';
$str = 'idiota'; 
$str = 'imbecil';
$str = 'ladrão';
$str = 'leprosa';
$str = 'leproso';
$str = 'louco';
$str = 'louca';
$str = 'macaca';
$str = 'macaco';
$str = 'macumbeiro';
$str = 'macumbeiro';
$str = 'mulata';
$str = 'mulato';
$str = 'nazista';
$str = 'otario';
$str = 'otaria';
$str = 'perereca';
$str = 'pinto';
$str = 'piranha';
$str = 'prostituo';
$str = 'prostituta';
$str = 'punheta';
$str = 'puta';
$str = 'puto';
$str = 'pênis';
$str = 'retardada';
$str = 'retardado';
$str = 'ridícula';
$str = 'racista';
$str = 'safado';
$str = 'safada';
$str = 'sapatão';
$str = 'sifilis';
$str = 'siririca'; 
$str = 'tarado';
$str = 'tarada';
$str = 'trouxa';
$str = 'traveco';
$str = 'vaca';
$str = 'vadia';
$str = 'viado';
$str = 'xereca';
$str = 'xota';
$str = 'vai toma no cu';
$str = 'lixo';

    if (strpos($comentario, 'caralho') !== false || strpos($comentario, 'porra') !== false || strpos($comentario, 'filho da puta') !== false || strpos($comentario, 'filha da puta') !== false || strpos($comentario, 'arrombado') !== false || strpos($comentario, 'arromada') !== false || strpos($comentario, 'bicha') !== false || strpos($comentario, 'boiola') !== false || strpos($comentario, 'buceta') !== false || strpos($comentario, 'boquete') !== false || strpos($comentario, 'bosta') !== false || strpos($comentario, 'bronha') !== false || strpos($comentario, 'bunda') !== false || strpos($comentario, 'burra') !== false || strpos($comentario, 'burro') !== false || strpos($comentario, 'bêbado') !== false || strpos($comentario, 'cacete') !== false || strpos($comentario, 'corno') !== false || strpos($comentario, 'corna') !== false || strpos($comentario, 'canalha') !== false || strpos($comentario, 'criolo') !== false || strpos($comentario, 'cu') !== false || strpos($comentario, 'cuzão') !== false || strpos($comentario, 'debiloide') !== false || strpos($texto, 'deficiente') !== false || strpos($texto, 'demônio') !== false || strpos($texto, 'doida') !== false || strpos($comentario, 'doido') !== false || strpos($comentario, 'escrota') !== false || strpos($comentario, 'escroto') !== false || strpos($comentario, 'facista') !== false || strpos($comentario, 'foda') !== false || strpos($comentario, 'fode') !== false || strpos($comentario, 'fudida') !== false || strpos($comentario, 'fudendo') !== false || strpos($comentario, 'gay') !== false || strpos($comentario, 'grelo') !== false || strpos($comentario, 'homo-sexual') !== false || strpos($comentario, 'idiota') !== false || strpos($comentario, 'imbecil') !== false || strpos($comentario, 'ladrão') !== false || strpos($comentario, 'lebrosa') !== false || strpos($comentario, 'lebroso') !== false || strpos($comentario, 'louco') !== false || strpos($comentario, 'louca') !== false || strpos($comentario, 'macaca') !== false || strpos($comentario, 'macaco') !== false || strpos($comentario, 'macumbeiro') !== false || strpos($comentario, 'macumbeira') !== false || strpos($comentario, 'mulata') !== false || strpos($comentario, 'mulato') !== false || strpos($comentario, 'nazista') !== false || strpos($comentario, 'otaria') !== false || strpos($comentario, 'otario') !== false || strpos($comentario, 'perereca') !== false || strpos($comentario, 'pinto') !== false || strpos($comentario, 'piranha') !== false || strpos($comentario, 'prostituto') !== false || strpos($comentario, 'prostituta') !== false || strpos($comentario, 'punheta') !== false || strpos($comentario, 'puto') !== false || strpos($comentario, 'puta') !== false || strpos($comentario, 'pênis') !== false || strpos($comentario, 'retardada') !== false || strpos($comentario, 'retardado') !== false || strpos($comentario, 'ridícula') !== false || strpos($comentario, 'racista') !== false || strpos($comentario, 'safada') !== false || strpos($comentario, 'safado') !== false || strpos($comentario, 'sapatão') !== false || strpos($comentario, 'sífilis') !== false || strpos($comentario, 'siririca') !== false || strpos($comentario, 'tarada') !== false || strpos($comentario, 'tarado') !== false || strpos($comentario, 'trouxa') !== false || strpos($comentario, 'traveco') !== false || strpos($comentario, 'vaca') !== false || strpos($comentario, 'vadia') !== false || strpos($comentario, 'viado') !== false || strpos($comentario, 'xereca') !== false || strpos($comentario, 'xota') !== false || strpos($comentario, 'vai toma no cu') !== false || strpos($comentario, 'lixo') !== false){
        header("location:feed.php");
        $msg ="<script>alert('LINGUAGEM INAPROPRIADA!! Por favor, utilize palavras apropriadas.')</script>";
    }else{
    if (mysqli_query($tec, "INSERT INTO `tb_comentarios` 
    (`codComentario`, `NomeComentario`, `txtComentario`, `codPublicacao`)
    VALUES (NULL, '$nome', '$comentario', '$codPublicacao');")){
        header("location:feed.php");
        $msg ="<script>alert('comentário incluído com sucesso!!')</script>";
    }
}


@session_start();
 $_SESSION['msg'] = $msg;
//header("location:feed.php");

?>