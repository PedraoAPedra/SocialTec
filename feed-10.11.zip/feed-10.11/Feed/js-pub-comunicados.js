//function de veriricar se é o representante fznd a pub
function verificarEmail(){
    var emailRepre = document.getElementById('email');
    var senhaRepre = document.getElementById('senha');
    var principal = document.querySelector('.box');
    var form = document.querySelector('.formulario');

    if(emailRepre.value == 'pedro'){
        if(principal.style.visibility = 'hidden'){
            principal.style.visibility = 'visible';
            principal.style.filter = 'blur(0px)';
            form.style.visibility = 'hidden';
        }
    }else{
        alert('errou');
    }
}