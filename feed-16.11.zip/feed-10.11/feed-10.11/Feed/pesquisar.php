<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SocialTec</title>
    <link rel="stylesheet" href="pesquisar.css">
    <script src="https://kit.fontawesome.com/27d55b8184.js" 
    crossorigin="anonymous"></script>

</head>
<header>
        <div class="menu">
            <img src="imagens/logo.png" alt="LOGO-SOCIALTEC" id="logo">

                <!-- BARRA DE PESQUISA
    <form action="pesquisar.php" method="post">
        <div class="barra">
            <input type="text" name="pesquisar" class="pesquisar" placeholder="Explore as publicações">
            <input type="submit" value="enviar" class="btnEnviar" onclick="searchData()"></input>
        </div>
    </form> -->

            <!-- <ul class="nav-links">
                <li><a href="cad_pub.php">Publicação</a></li> -->

            <div class="input">
                <input type="checkbox" class="checkbox" id="chk">
                    <label for="chk" class="label">
                    <i class="fas fa-moon"></i>
                    <i class="fas fa-sun"></i>
                    <div class="ball"></div>
                    </label>
            </div>
            
            </ul>   
            
            <div class="burguer">
                <div class="linha1"></div>
                <div class="linha2"></div>
                <div class="linha3"></div>
            </div>

        </div>

    </header>

    <fieldset class="grupos">
    <a href="feed.php" id="nome"><h1>SocialTec</h1></a>

        <form action="pesquisar.php" method="post">
        <div class="barra">
            <input type="text" name="pesquisar" class="pesquisar" placeholder="Explore as publicações">
            <input type="submit" value="enviar" class="btnEnviar" onclick="searchData()"></input>
        </div>
        </form>
        <fieldset class="grupoHTML">
            <img src="imagens/chat-p.png" alt="logo-html" class="logoHTML">
            <h2>Chat</h2>
        </fieldset>
        <fieldset class="grupoCSS">
            <img src="imagens/grupo-p.png" alt="logo-css" class="logoCSS">
            <h2>Grupos</h2>
        </fieldset>
        <fieldset class="grupoJS">
            <img src="imagens/comunicado-p.png" alt="logo-js" class="logoJS">
            <h2>Comunicados</h2>
        </fieldset>

        
        
    </fieldset>

    <div class="nav2">
    <img src="imagens/perfil" id="fotoPerfil">
    <h1 class="Nome">Nome do usuário</h1>
    <a href="#" id="verPerfil">Ver Perfil</a>

    <div class="menuToggle"></div>
    <div class="menuB"></div>

    </div>

    <script>
        let menuToggle = document.querySelector('.menuToggle');
        menuToggle.onclick = function() {
        menuToggle.classList.toggle('active')
        }
    </script>


    </div>

    <div class="botao"><!--BOTAO DOS GRUPOS-->
    <div class="linha4"></div>
    <div class="linha5"></div>
    <div class="linha6"></div>
    </div>
<body>
<?php
extract($_POST);
extract($_FILES);
require('conectar.php');

if(!empty($_POST['pesquisar'])){
    $pesquisar = $_POST['pesquisar'];
    $result_pesquisa = "SELECT * FROM tb_publicacao WHERE nome LIKE '%$pesquisar%' or texto LIKE '%$pesquisar%'";
    $resultado_pesquisa = mysqli_query($tec, $result_pesquisa);
    
    echo "<fieldset class=principal>";

    while($row_pesquisa = mysqli_fetch_array($resultado_pesquisa)){
        echo "<div class=pub>";//inicio da div pub
        echo "<p class = codigo>Código: $row_pesquisa[codigo]</p>";
        echo "<h3>$row_pesquisa[nome]</h3>";
        echo "<textarea class=txt disabled=true>$row_pesquisa[texto]</textarea>";
        echo "<textarea class=trechoCod disabled=true>$row_pesquisa[trechoCod]</textarea>";
        echo "<img src = $row_pesquisa[url] alt='Faça o update da imagem do seu código'>";
        echo "<div class=opcoes>";//inicio da div opcoes
        echo "<input type=button value=Curtir class=curtir onclick=curtir()>";
        echo "</div>";//final da div opcoes
        echo "<div class=curtida>";//inicio da div curtidas
        echo "</div>";//final da div curtidas
        ?>
        <form action="comentarioFeito.act.php" method="post">
        <input type="hidden" name="codPublicacao" value="<?php echo $row_pesquisa['codigo'] ?>">
        
        <input type="text" name="nome" id="nomeComentario" placeholder="Escreva seu nome" required>
        <textarea name="comentario" id="txtComentario" maxlength="200" placeholder="Escreva um comentário..." required></textarea>
        <input type="submit" value="Enviar">
        <?php
        echo "</form>";
        echo "<fieldset class=partComentario>";//inicio da caixa com 
        $comentarios = mysqli_query($tec, "Select * from `tb_comentarios` where `codPublicacao` = '$row_pesquisa[codigo]'");
        while($comentario = mysqli_fetch_array($comentarios)){
            echo "<p class=nomeComentFeito>Nome: $comentario[NomeComentario]</p>";
            echo "<textarea class=txtComentFeito disabled=true>$comentario[txtComentario]</textarea>";
        }//FINAL DA PARTE DOS COMENTARIOS
        echo "</fieldset>";//final da caixa com comentarios
        echo "</div>";//final da div pub



        
    }
    echo "</fieldset>";
}else{
    header("location:feed.php");
    //@session_start();
    //$_SESSION['msg'] = $msg;
    //header("location:feed.php");
}
?>

<script src="js-pesquisar.js"></script>
</body>
</html>

