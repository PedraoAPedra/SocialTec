<?php
extract($_POST);
extract($_FILES);
require('conectar.php');

$url = "imagens/".md5(time().$foto['name']).".jpg";

//palavras e expressões proibidas
$str = 'porra';
$str = 'caralho';
$str = 'filho da puta'; 
$str = 'filha da puta';
$str = 'arombado';
$str = 'arrombada';
$str = 'bicha';
$str = 'boiola';
$str = 'buceta';
$str = 'boquete'; 
$str = 'bosta';
$str = 'bronha';
$str = 'bunda'; 
$str = 'burra';
$str = 'burro';
$str = 'bêbado';
$str = 'cacete';
$str = 'corno';
$str = 'corna';
$str = 'canalha';
$str = 'criolo';
$str = 'cu';
$str = 'cuzão';
$str = 'debiloide';
$str = 'deficiente';
$str = 'demônio';
$str = 'doida';
$str = 'doido';
$str = 'escroto';
$str = 'escrota';
$str = 'facista';
$str = 'foda';
$str = 'fode';
$str = 'fudida';
$str = 'fudendo';
$str = 'gay';
$str = 'grelo';
$str = 'homo-sexual';
$str = 'idiota'; 
$str = 'imbecil';
$str = 'ladrão';
$str = 'leprosa';
$str = 'leproso';
$str = 'louco';
$str = 'louca';
$str = 'macaca';
$str = 'macaco';
$str = 'macumbeiro';
$str = 'macumbeiro';
$str = 'mulata';
$str = 'mulato';
$str = 'nazista';
$str = 'otario';
$str = 'otaria';
$str = 'perereca';
$str = 'pinto';
$str = 'piranha';
$str = 'prostituo';
$str = 'prostituta';
$str = 'punheta';
$str = 'puta';
$str = 'puto';
$str = 'pênis';
$str = 'retardada';
$str = 'retardado';
$str = 'ridícula';
$str = 'racista';
$str = 'safado';
$str = 'safada';
$str = 'sapatão';
$str = 'sifilis';
$str = 'siririca'; 
$str = 'tarado';
$str = 'tarada';
$str = 'trouxa';
$str = 'traveco';
$str = 'vaca';
$str = 'vadia';
$str = 'viado';
$str = 'xereca';
$str = 'xota';
$str = 'vai toma no cu';
$str = 'lixo';

   
    if(strpos($nome, 'caralho') !== false || strpos($nome, 'porra') !== false || strpos($nome, 'filho da puta') !== false || strpos($nome, 'filha da puta') !== false || strpos($nome, 'arrombado') !== false || strpos($nome, 'arromada') !== false || strpos($nome, 'bicha') !== false || strpos($nome, 'boiola') !== false || strpos($nome, 'buceta') !== false || strpos($nome, 'boquete') !== false || strpos($nome, 'bosta') !== false || strpos($nome, 'bronha') !== false || strpos($nome, 'bunda') !== false || strpos($nome, 'burra') !== false || strpos($nome, 'burro') !== false || strpos($nome, 'bêbado') !== false || strpos($nome, 'cacete') !== false || strpos($nome, 'corno') !== false || strpos($nome, 'corna') !== false || strpos($nome, 'canalha') !== false || strpos($nome, 'criolo') !== false || strpos($nome, 'cu') !== false || strpos($nome, 'cuzão') !== false || strpos($nome, 'debiloide') !== false || strpos($nome, 'deficiente') !== false || strpos($nome, 'demônio') !== false || strpos($nome, 'doida') !== false || strpos($nome, 'doido') !== false || strpos($nome, 'escrota') !== false || strpos($nome, 'escroto') !== false || strpos($nome, 'facista') !== false || strpos($nome, 'foda') !== false || strpos($nome, 'fode') !== false || strpos($nome, 'fudida') !== false || strpos($nome, 'fudendo') !== false || strpos($nome, 'gay') !== false || strpos($nome, 'grelo') !== false || strpos($nome, 'homo-sexual') !== false || strpos($nome, 'idiota') !== false || strpos($nome, 'imbecil') !== false || strpos($nome, 'ladrão') !== false || strpos($nome, 'lebrosa') !== false || strpos($nome, 'lebroso') !== false || strpos($nome, 'louco') !== false || strpos($nome, 'louca') !== false || strpos($nome, 'macaca') !== false || strpos($nome, 'macaco') !== false || strpos($nome, 'macumbeiro') !== false || strpos($nome, 'macumbeira') !== false || strpos($nome, 'mulata') !== false || strpos($nome, 'mulato') !== false || strpos($nome, 'nazista') !== false || strpos($nome, 'otaria') !== false || strpos($nome, 'otario') !== false || strpos($nome, 'perereca') !== false || strpos($nome, 'pinto') !== false || strpos($nome, 'piranha') !== false || strpos($nome, 'prostituto') !== false || strpos($nome, 'prostituta') !== false || strpos($nome, 'punheta') !== false || strpos($nome, 'puto') !== false || strpos($nome, 'puta') !== false || strpos($nome, 'pênis') !== false || strpos($nome, 'retardada') !== false || strpos($nome, 'retardado') !== false || strpos($nome, 'ridícula') !== false || strpos($nome, 'racista') !== false || strpos($nome, 'safada') !== false || strpos($nome, 'safado') !== false || strpos($nome, 'sapatão') !== false || strpos($nome, 'sífilis') !== false || strpos($nome, 'siririca') !== false || strpos($nome, 'tarada') !== false || strpos($nome, 'tarado') !== false || strpos($nome, 'trouxa') !== false || strpos($nome, 'traveco') !== false || strpos($nome, 'vaca') !== false || strpos($nome, 'vadia') !== false || strpos($nome, 'viado') !== false || strpos($nome, 'xereca') !== false || strpos($nome, 'xota') !== false || strpos($nome, 'vai toma no cu') !== false || strpos($nome, 'lixo') !== false){
        header("location:feed.php#abrirModal"); 
        $msg ="<script>alert('LINGUAGEM INAPROPRIADA!! Por favor, utilize palavras apropriadas.')</script>";

    }else if(strpos($texto, 'caralho') !== false || strpos($texto, 'porra') !== false || strpos($texto, 'filho da puta') !== false || strpos($texto, 'filha da puta') !== false || strpos($texto, 'arrombado') !== false || strpos($texto, 'arromada') !== false || strpos($texto, 'bicha') !== false || strpos($texto, 'boiola') !== false || strpos($texto, 'buceta') !== false || strpos($texto, 'boquete') !== false || strpos($texto, 'bosta') !== false || strpos($texto, 'bronha') !== false || strpos($texto, 'bunda') !== false || strpos($texto, 'burra') !== false || strpos($texto, 'burro') !== false || strpos($texto, 'bêbado') !== false || strpos($texto, 'cacete') !== false || strpos($texto, 'corno') !== false || strpos($texto, 'corna') !== false || strpos($texto, 'canalha') !== false || strpos($texto, 'criolo') !== false || strpos($texto, 'cu') !== false || strpos($texto, 'cuzão') !== false || strpos($texto, 'debiloide') !== false || strpos($texto, 'deficiente') !== false || strpos($texto, 'demônio') !== false || strpos($texto, 'doida') !== false || strpos($texto, 'doido') !== false || strpos($texto, 'escrota') !== false || strpos($texto, 'escroto') !== false || strpos($texto, 'facista') !== false || strpos($texto, 'foda') !== false || strpos($texto, 'fode') !== false || strpos($texto, 'fudida') !== false || strpos($texto, 'fudendo') !== false || strpos($texto, 'gay') !== false || strpos($texto, 'grelo') !== false || strpos($texto, 'homo-sexual') !== false || strpos($texto, 'idiota') !== false || strpos($texto, 'imbecil') !== false || strpos($texto, 'ladrão') !== false || strpos($texto, 'lebrosa') !== false || strpos($texto, 'lebroso') !== false || strpos($texto, 'louco') !== false || strpos($texto, 'louca') !== false || strpos($texto, 'macaca') !== false || strpos($texto, 'macaco') !== false || strpos($texto, 'macumbeiro') !== false || strpos($texto, 'macumbeira') !== false || strpos($texto, 'mulata') !== false || strpos($texto, 'mulato') !== false || strpos($texto, 'nazista') !== false || strpos($texto, 'otaria') !== false || strpos($texto, 'otario') !== false || strpos($texto, 'perereca') !== false || strpos($texto, 'pinto') !== false || strpos($texto, 'piranha') !== false || strpos($texto, 'prostituto') !== false || strpos($texto, 'prostituta') !== false || strpos($texto, 'punheta') !== false || strpos($texto, 'puto') !== false || strpos($texto, 'puta') !== false || strpos($texto, 'pênis') !== false || strpos($texto, 'retardada') !== false || strpos($texto, 'retardado') !== false || strpos($texto, 'ridícula') !== false || strpos($texto, 'racista') !== false || strpos($texto, 'safada') !== false || strpos($texto, 'safado') !== false || strpos($texto, 'sapatão') !== false || strpos($texto, 'sífilis') !== false || strpos($texto, 'siririca') !== false || strpos($texto, 'tarada') !== false || strpos($texto, 'tarado') !== false || strpos($texto, 'trouxa') !== false || strpos($texto, 'traveco') !== false || strpos($texto, 'vaca') !== false || strpos($texto, 'vadia') !== false || strpos($texto, 'viado') !== false || strpos($texto, 'xereca') !== false || strpos($texto, 'xota') !== false || strpos($texto, 'vai toma no cu') !== false || strpos($texto, 'lixo') !== false){
        header("location:feed.php#abrirModal");
        $msg ="<script>alert('LINGUAGEM INAPROPRIADA!! Por favor, utilize palavras apropriadas.')</script>";
    }
    else if($nome == "" || $texto == ""){
        header("location:feed.php#abrirModal");

    }else{
        if(move_uploaded_file($foto['tmp_name'],$url)){
            if(mysqli_query($tec, "INSERT INTO `tb_publicacao` 
            (`codigo`, `nome`, `texto`, `trechoCod`, `url`) 
            VALUES (NULL, '$nome', '$texto', '$trechoCod', '$url');")){
                header("location:feed.php");
                $msg ="<script>alert('incluido')</>";
            }
                }else if(mysqli_query($tec, "INSERT INTO `tb_publicacao` 
                (`codigo`, `nome`, `texto`, `trechoCod`, `url`) 
                VALUES (NULL, '$nome', '$texto', '$trechoCod', '$url');")){
                    header("location:feed.php");
                    $msg ="<script>alert('incluido')</>";
                }

    }


@session_start();
 $_SESSION['msg'] = $msg;
//header("location:feed.php");

?>