<?php
    $idPost = $_GET['id'];

    $adiciona = "INSERT INTO curtidas (id_post) VALUES ('idPosts)";

    if(mysqli_query($adiciona)){
        echo "<script>windows.history.back();</script>";
    }else{
        echo "Erro ao curtir";
    }

?> 