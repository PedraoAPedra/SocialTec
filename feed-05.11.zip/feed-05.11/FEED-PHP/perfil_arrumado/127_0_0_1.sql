-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 27-Out-2022 às 19:31
-- Versão do servidor: 8.0.27
-- versão do PHP: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `bd_socialtec`
--
CREATE DATABASE IF NOT EXISTS `bd_socialtec` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `bd_socialtec`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_perfil`
--

DROP TABLE IF EXISTS `tb_perfil`;
CREATE TABLE IF NOT EXISTS `tb_perfil` (
  `codigo` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `txt` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `tb_perfil`
--

INSERT INTO `tb_perfil` (`codigo`, `nome`, `url`, `txt`) VALUES
(1, 'João Astolfo Figueiredo', 'imagens/ca74024c3442011651db8c8f44893cf8.jpg', ''),
(2, 'Guilherme Burges Safado', 'imagens/4d843c354b24388d98bf5e1b998702cb.jpg', ''),
(3, 'Gustavo Fumante Safado', 'imagens/682be34dce459d219f992b8cd05c3ab7.jpg', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_publicacao`
--

DROP TABLE IF EXISTS `tb_publicacao`;
CREATE TABLE IF NOT EXISTS `tb_publicacao` (
  `codigo` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `texto` varchar(300) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `trechoCod` varchar(400) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `tb_publicacao`
--

INSERT INTO `tb_publicacao` (`codigo`, `nome`, `texto`, `trechoCod`) VALUES
(37, 'asas', 'aa', 'sss\r\nssssssssss\r\nssssssssssssssssssss\r\nssssssssssssssssssssssssss\r\nsssssssssssssssssssssssssssss\r\nsssssssssssssssssssssssssss\r\nsssssssssssssssssssssssssss\r\nsssssssssssssssss\r\nssssssssssssssss\r\nsssssssssss\r\nsssssssssssssssss\r\nssssssssssssssssss\r\nssssssssssssssssss\r\nsssssssssssssssssss\r\nssssssssssssssssssssss\r\nsssssssssss\r\nssssssssssssssss\r\nssssssssss\r\n'),
(36, 'pedro henryq', 'como linkar essa area', 'asas'),
(35, 'diego', 'justino', 'concei'),
(34, 'pedro', 'henryque', 'merlin'),
(38, 'pedro', 'sa', 'sssssssssssssss\r\nsssssssssssssssssssssss\r\nssssssssssssssssssssssssssssss\r\nssssssssssssssssssssssssssss\r\nsssssssssssssssssssssssssssss\r\nsssssssssssssssssssssssssssss\r\nssssssssssssssssssssssssssssss'),
(41, 'peeddo', 'dddddddddd', '*{\r\n    margin: 0;\r\n}\r\n\r\nbody{\r\n    background-*{\r\n    margin: 0;\r\n}\r\n\r\nbody{\r\n    background-color: #fff;\r\n    transition: background 0.2s linear;\r\n}\r\n\r\n/*PARTE DO MENU*/\r\n.nav-menu{\r\n    background: #5c1374;\r\n    display: flex;\r\n    justify-content: space-between;\r\n    align-items: center;\r\n    height: 70px;\r\n    position: fixed;\r\n    right: 0;\r\n    top: 0;\r\n    width: 100%;\r\n}\r\n\r\n.nav-menu img.');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
