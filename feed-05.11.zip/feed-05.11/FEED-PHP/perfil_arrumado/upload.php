
<?php
extract($_POST);
    extract($_FILES);
    require('connect.php');
    //var_dump($foto);
    if($foto['tmp_name'] != ""){
        // echo "passei1";
        $foto = $_FILES ['foto'];
        $url = "imagens/".md5(time()).".jpg";
            // echo "passei2";
            mysqli_query($con, "UPDATE `tb_perfil` SET `url` = '$url' WHERE `tb_perfil`.`codigo` = '$codigo';");
            move_uploaded_file($foto['tmp_name'],$url);

        }
        
        header("location:perfil.php?cod=$codigo");

?>