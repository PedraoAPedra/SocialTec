<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="perfil.css">
    <link rel="icon" href="imagens/aba.jpg">
    <title>Perfil</title>
</head>
<body>  
    
    
    <!-- Parte da Nav-Bar  -->
    <header>
        <nav>
            <a class= "logo" href="#"><img src="imagens/logo tcca.png" alt=""></a>
            <ul class="nav-list">
                <li><a href="#">Feed</a></li>
                <li><a href="#">Perfil</a></li>
                <li><a href="#">Sobre Nós</a></li>
            </ul>
        </nav>
    </header>

    <!-- Corpo da Página -->
    <?php

        require('connect.php');
        $codigo = $_GET['cod'];
        $busca = mysqli_query($con,"Select * from `tb_perfil` where `codigo` = '$codigo'");
        $perfil = mysqli_fetch_array($busca);

?>

    <main>
        <div class="container">
                     <div class="perfil">
                        <form action="upload.php" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="codigo" value="<?php echo $perfil['codigo']; ?>">
                        <div class="max-width">
                            <div class="imageContainer">
                                <label for="inputFoto">
                                    <?php
                                        if($perfil['url'] == ""){
                                            echo "<img src=imagens/perfil.jpg >";
                                        }else{
                                            echo "<img src=\"$perfil[url]\" alt=\"Selecione uma imagem\" id=\"imgPhoto\">";
                                        }

                                    ?>
                                
                                </label>
                            </div>
                        </div>
                    
                        <input type="file" id="inputFoto" name="foto" accept="image/*" onchange="this.form.submit()">
                        </form>

                        <h6> <?php echo $perfil['nome']; ?></h6>
                    </div>
            <div class="fundo" id="fundo">
                <!-- <div class="usuario">
                    <img class="avatar" src="imagens/imagens perfil.jpg" alt="Avatar"> -->
                    <img src="imagens/fundo.jpg" alt="" id="capaF">

            </div>

                
        </div>
            <div class="about"> 
                <h1>Sobre mim</h1>
                <textarea name="" id="sobre" cols="90" rows="15" placeholder="Conte-nos sobre você"></textarea>
            </div>
        </div>

    </main>

    <!-- FOOTER COM OS ICONS DE ALTERAÇÃO -->

    <footer>
        <div class="icons">
                <figure>
                   <a href="" title="Alterar capa"> <img src="imagens/image-add-regular-84.png" class="capa"></a>
                </figure>

                <figure>
                   <a href="" title="Alterar biografia"> <img src="imagens/altBio.png" class="bio"></a>
                </figure>
        </div>

    </footer>

        <script src="script.js"></script>


</body>
</html>