<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grupos</title>
    <link rel="stylesheet" href="estilo-Grupos.css">
</head>
<body>
    <nav>

<a href="#abrirModal">Open Modal</a>

<div id="abrirModal" class="modal">
<a href="#fechar" title="Fechar" class="fechar">x</a>
  <h2>Janela Modal</h2>
  <p>Esta é uma simples janela de modal.</p>
  <p>Você pode fazer qualquer coisa aqui, página de Login, pop-ups, ou formulários</p>
</div>
</body>
</html>